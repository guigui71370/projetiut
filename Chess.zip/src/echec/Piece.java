package echec;

public abstract class Piece {
	
	public static final String WHITE_COLOR = "Blanc";
	public static final String BLACK_COLOR = "Noir";
	
	protected String color;
	
	public Piece(String couleur) {
		color = couleur;
	}
	
	public abstract int getValeur();

	public abstract void showPossibleMoves(int pos, Case[] board);

}
