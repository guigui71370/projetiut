package echec;

public class Tour extends Piece{

	public Tour(String couleur) {
		super(couleur);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getValeur() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void showPossibleMoves(int pos, Case[] board) {
		// TODO Auto-generated method stub
		
	}

}
