package echec;

public class Case {
	
	private String coord;
	
	private Piece piece;
	
	public Case(String nom) {
		coord = nom;
	}

	public String getCoord() {
		return coord;
	}

	public Piece getPiece() {
		return piece;
	}

	public void setPiece(Piece piece) {
		this.piece = piece;
	}
	
	public void addObserver() {
		//TODO
	}

	public void update() {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
